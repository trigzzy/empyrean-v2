__CONFIG__ = {
    'webhook': '',
    'antidebug': False,
    'browsers': True,
    'discordtoken': True,
    'injection': False,
    'startup': False,
    'systeminfo': True,
}
